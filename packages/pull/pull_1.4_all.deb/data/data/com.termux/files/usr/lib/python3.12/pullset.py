#!/usr/bin/python

import os, sys, time

# Color
N = '\033[0m'
D = '\033[90m'
W = '\033[1;37m'
B = '\033[1;34m'
R = '\033[1;31m'
G = '\033[1;32m'
Y = '\033[1;33m'
C = '\033[1;36m'
M = '\033[1;35m'

# Function
def main(s):
    for c in s + "\n":
       sys.stdout.write(c)
       sys.stdout.flush()
       time.sleep(0.050)

# Main menu
ask= G + '[' + W + 'Name File' + G + ']'
dwn= G + '[' + Y + '+' + G + ']'
up = G + '[' + Y + '!' + G + ']'
chk= G + '[' + M + '•' + G + ']'
error= G + '[' + R + '!' + G + ']' + R
cose= Y + '┌──['+G+'termux@localhost'+Y+']\n└─'+G+'$ '+N
version="""{}1.4""".format(M)
aut="""{}Djunekz""".format(M)
tool='{}㉿'.format(M)
menu="""
{}[{}•{}]{} Search Package
{}[{}•{}]{} Install Package
{}[{}•{}]{} Info Package
{}[{}•{}]{} Remove Package
{}[{}•{}]{} Update and Upgrade Repository
{}[{}•{}]{} exit
""".format(G,Y,G,W,G,Y,G,W,G,Y,G,W,G,Y,G,W,G,Y,G,W,G,R,G,R)

# Logo
logo="""
{} Version: {}
{} Author : {}{}
 _____     _ _ _____         _   
|  _  |_ _| | |  _  |___ ___| |_ 
|   __| | | | |   __| .'|  _| '_|
|__|  |___|_|_|__|  |__,|___|_,_|{}
""".format(G,version,G,aut,Y,N)

help="""
  {}Information this tool command:

 {}help{},{} h{}	information for this tool
 {}search{},{} s{}	search package you want to search
 {}install{},{} i{}	installing package you want to search
 {}info{},{} inf{}	information package
 {}remove{},{} r{}	remove or uninstall package
 {}update{}, {}up{}	update and upgrade repository
 {}exit{},{} x{}	quit or exiting this tool
""".format(N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N,Y,N)

