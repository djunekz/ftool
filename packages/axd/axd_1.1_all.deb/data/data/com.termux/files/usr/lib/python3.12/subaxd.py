#!/usr/bin/env python
#-*- coding: utf-8 -*-
import sys, os, time
import subprocess

try:
    import requests
    import os.path
    import time
    import sys
except ImportError:
    print(" You dont have a dependency requests!")
    print(" install requests ...")
    os.system("python -m pip install requests")
finally:
    import requests

import requests
import os.path

os.system ("clear")
# Color Variable
N = '\033[0m'
D = '\033[90m'
W = '\033[1;37m'
B = '\033[1;34m'
R = '\033[1;31m'
G = '\033[1;32m'
Y = '\033[1;33m'
C = '\033[1;36m'
b = '\033[31m'
h = '\033[32m'
m = '\033[00m'
vs="""1.1"""
banner = """

\033[31m   █████╗ ██╗  ██╗██████╗  \033[0m Author :\033[93m D J U N E K Z\033[0m
\033[31m  ██╔══██╗╚██╗██╔╝██╔══██╗ \033[0m Date   :\033[93m 2020-09-16\033[0m
\033[31m  ███████║ ╚███╔╝ ██║  ██║ \033[0m Tools  :\033[93m Auto Xploit Deface\033[0m
\033[97m  ██╔══██║ ██╔██╗ ██║  ██║ \033[0m Version:\033[93m {}\033[0m
\033[97m  ██║  ██║██╔╝ ██╗██████╔╝ \033[0m Github :\033[93m /djunekz/axd\033[0m
\033[97m  ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝  \033[0m Email  :\033[93m gab288.gab288@passinbox.com\033[0m
""".format(vs)
menu = """
   {}Note{}:
   {}Sebelumnya, persiapkan file script deface ( .html / .php / lainnya )
   jangan lupa juga buatlah file {}target.txt{} dan juga list website di
   dalam file {}target.txt

     {}[{}1{}]{} Execute     {}[{}2{}]{} Update    {}[{}3{}]{} Contact Me    {}[{}x{}]{} Exit
""".format(R,N,Y,G,Y,G,G,Y,G,W,G,Y,G,W,G,Y,G,W,G,R,G,Y)
