#!/usr/bin/env python3

# Import / Module / Library
import os
import sys
import time

# Note
"""
  Tool ini dibuat: 24 Juny 2025
  Pembuat: Djunekz/Anonymous/Hmei7/RedHh/MrxXx/MrDee
  Email: gab288.gab288@passinbox.com
  Fungsi Tool: untuk memberi warna tampilan dan tulisan terminal emulator
               (termux) serta merubah tampilan command prompt
"""

# Color Variable
DG='\33[90m'
LR='\33[91m'
LG='\33[92m'
LY='\33[93m'
LB='\33[94m'
LM='\33[95m'
LC='\33[96m'
W='\33[97m'
CL='\33[0m'

# Function
error=LY+'['+LR+'!'+LY+'] '+LR
sukses=LY+'['+LG+'√'+LY+'] '+LG
up=LY+'['+LM+'+'+LY+'] '+LG
dwn=LY+'['+LC+'-'+LY+'] '+LG
ask=LY+'['+W+'?'+LY+'] '+LG
cmdp=LY+'┌──['+LG+'termux@localhost'+LY+']─['+W+'...'+LY+']\n  └─'+LG+'$ '+CL
cmdd="PS1='\\[\\e[1;33m\\]┌──[\\[\\e[1;92m\\]termux\\[\\e[1;38m\\]@\\[\\e[1;92m\\]$HOSTNAME\\e[0m\\]\\[\\e[1;33m\\]]─[\\[\\e[1;30m\\]\\w\\[\\e[0m\\]\\[\\e[0;97m\\]\\[\\e[1;33m\\]]\n\\[\\e[1;33m\\]└─\\[\\e[1;92m\\]\\$\\[\\e[0m\\] '"
import time
import sys

# Logo and Menu
vs="""{}1.0.0{}""".format(LG,CL)

logo="""{}
 _____               _____ _       _      
|_   _|___ ___ _____|   __| |_ _ _| |___  
  | | | -_|  _|     |__   |  _| | | | -_| 
  |_| |___|_| |_|_|_|_____|_| |_  |_|___| 
   {} T E R M U X   S T Y L E{}   |___|{}     
""".format(LY,LM,LY,vs)
abt="""{}
Version {}{}
Head repository {}https://github.com/djunekz/termstyle{}
Note {}this tool only termux{}
Command prompt style:
  {}{}
License {}GNU General Public License
""".format(W,vs,W,LG,W,LG,W,cmdp,W,LG)
help="""
{}Help:
- choose 1 for change color terminal
- choose 2 for change command prompt
- choose 3 for change cursor
""".format(W)

menu="""
{}[{}1{}]{} Change Color
{}[{}2{}]{} Change CommandPrompt
{}[{}3{}]{} Change Cursor
{}[{}x{}]{} exit
""".format(LG,W,LG,LY,LG,W,LG,LY,LG,W,LG,LY,LG,LR,LG,LR)

menu2="""
{}[{}1{}]{} Change cursor > {}▁
{}[{}2{}]{} Change cursor > {}|
{}[{}3{}]{} Change cursor > {}❚
{}[{}x{}]{} back
""".format(LG,W,LG,LY,W,LG,W,LG,LY,W,LG,W,LG,LY,W,LG,LR,LG,LR)
