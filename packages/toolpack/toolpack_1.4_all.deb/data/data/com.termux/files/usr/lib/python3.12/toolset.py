#!/data/data/com.termux/files/usr/bin/env python3

import os, sys, time

# Color
N = '\033[0m'
D = '\033[90m'
W = '\033[1;37m'
B = '\033[1;34m'
R = '\033[1;31m'
G = '\033[1;32m'
Y = '\033[1;33m'
C = '\033[1;36m'
M = '\033[1;35m'

# Function
def main(s):
    for c in s + "\n":
       sys.stdout.write(c)
       sys.stdout.flush()
       time.sleep(0.050)

# Main menu
ask= G + '[' + W + 'Name File' + G + ']'
dwn= G + '[' + Y + '+' + G + ']'
up = G + '[' + R + '-' + G + ']'
chk= G + '[' + M + '•' + G + ']'
pp= G + '[' + M + 'Python2 (.py)' + G + ']' + W
pp3= G + '[' + M + 'Python (.py)' + G + ']' + W
shh= G + '[' + M + 'Shell (.sh)' + G + ']' + W
sukses= G + '[' + W + '!' + G + ']'
error= R + '[' + W + '!' + R + ']'
satu= G + '[' + W + '1' + G + ']' + Y
dua= G + '[' + W + '2' + G + ']' + Y
tiga= G + '[' + W + '3' + G + ']' + Y
empat= G + '[' + W + '4' + G + ']' + Y
lima= G + '[' + W + '5' + G + ']' + Y
keluar= G + '[' + R + 'x' + G + ']' + R
version="""{}1.4""".format(M)
menutp="""
{} Encrypt Tool
{} Build Packages
{} Check list/Upload to Public
{} Help
{} Exit
""".format(satu,dua,tiga,empat,keluar)
menuenc="""
{} File python2 {}>{} .py {}> {}#!/usr/bin/python2
{} File python3 {}>{} .py {}> {}#!/usr/bin/python
{} File Shell {}>{} .sh {}> {}#!/usr/bin/bash
{} back
""".format(satu,W,Y,W,R,dua,W,Y,W,R,tiga,W,Y,W,R,keluar)
menubuild="""
{} Check your directory
{} Build your package
{} back
""".format(satu,dua,keluar)
menulist="""
{} List public package
{} Upload your package to public installation
{} back
""".format(satu,dua,keluar)

# Logo
TP="""{}\v
\t _____         _ _____         _
\t|_   _|___ ___| |  _  |___ ___| |_  {}Version: {}
\t{}  | | | . | . | |   __| .'|  _| '_|
\t  |_| |___|___|_|__|  |__,|___|_,_| {}Author: {}Djunekz{}
\t    [ Simple tool fo everyone ]{}
""".format(Y,C,version,Y,C,M,G,N)

ENC="""{}\v
\t _____                     _   
\t|   __|___ ___ ___ _ _ ___| |_ 
\t|   __|   |  _|  _| | | . |  _|
\t|_____|_|_|___|_| |_  |  _|_|  
\t  {}Encrypt Tools   {}|___|_|{}
""".format(Y,G,Y,N)

BUILD="""{}\v
\t _____     _ _   _ _____         _
\t| __  |_ _|_| |_| |_   _|___ ___| |
\t| __ -| | | | | . | | | | . | . | |
\t|_____|___|_|_|___| |_| |___|___|_|{}
""".format(Y,N)

TUP="""{}\v
\t _____         _ _____ _____ 
\t|_   _|___ ___| |  |  |  _  |
\t  | | | . | . | |  |  |   __|
\t  |_| |___|___|_|_____|__|   
\t     {}Tool Update Public {}
""".format(Y,G,N)

ttp="""
\t[ Simple tool for everyone ]
"""

helptp="""
{}- Encrypt Tool:{}
Encrypt file shell(bash(.sh)) and file python2, python3 (.py)
Before encrypting,
please ensure that the file header is written with {}#!/usr/bin/bash{} for shell files, or {}#!/usr/bin/python{} for python or python3 files, while for python2 it is written with {}#!/usr/bin/python2

{}- Build Package:{}
Debian file creation package for installation using pkg install and apt install, please make sure the file extension has been changed to bin execute. without extensions such as .sh or .py so that later when it is run it only writes the file name without the extension.

{}- Check List/Upload to Public:{}
Check List to see the available tools, and to Upload to Public is used for the purpose of distributing Debian packages so that they can be used publicly.{}
""".format(Y,G,R,G,R,G,R,Y,G,Y,G,N)
