#!/usr/bin/python2
import os, sys, time, subprocess
try:
  import requests
except ImportError:
  os.system("pip install requests")
finally:
  import requests

import requests
import string
import random
import time
import sys
import os

N='\33[0m'
R='\33[31m'
G='\33[32m'
Y='\33[33m'
B='\33[34m'
W='\33[97m'
LR='\33[91m'
LG='\33[92m'
LY='\33[93m'
LB='\33[94m'
BY='\33[43m'

vs="""{}2.6 - djunekz""".format(LY)
ct="""{}13/05/2016""".format(LY)
cma= LG +"["+LY+">"+LG+"]"+N
cmc= LG +"["+LR+"!"+LG+"]"+N
cms= LG +"["+W+">"+LG+"]"+N
warn= LG +"[ "+LR+"WARNING!"+LG+" ]" +N
banner="""\v{}
\t  __      __      ___.   ________      _________   ____
\t /  \    /  \ ____\_ |__ \______ \    /  _  \   \ /   /
\t \   \/\/   // __ \| __ \ |    |  \  /  /_\  \   Y   /{}
\t  \        /\  ___/| \_\ \|    `   \/    |    \     /
\t   \__/\  /  \___  >___  /_______  /\____|__  /\___/
\t        \/       \/    \/        \/         \/

{} WebDAV File Upload Exploiter
{} Created Tool : {}
{} Version : {}""".format(LR,W,cma,cma,ct,cma,vs)
