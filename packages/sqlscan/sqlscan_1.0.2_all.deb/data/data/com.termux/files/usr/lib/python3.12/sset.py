#!/usr/bin/python3
import time, os, sys

N='\33[0m'
R='\33[31m'
G='\33[32m'
Y='\33[33m'
B='\33[34m'
W='\33[97m'
LR='\33[91m'
LG='\33[92m'
LY='\33[93m'
LB='\33[94m'
LM='\33[95m'
LC='\33[96m'
BY='\33[43m'

vrs="""{}1.0.2{}#termux{}""".format(W,LR,LY)
aut="""{}djunekz{}""".format(W,LY)
sql="""{}
         _                 
 ___ ___| |___ ___ ___ ___   {}
|_ -| . | |_ -|  _| .'|   |
|___|_  |_|___|___|__,|_|_|  {}
      |_|                 {}
""".format(LY,vrs,aut,N)

failed="\r\33[97m[\33[0m%s\33[97m] [\33[91mFAILED\33[97m]\33[0m "%(time.strftime("%X"))
novuln="\r\33[97m[\33[0m%s\33[97m] [\33[93mNO VULN\33[97m]\33[0m "%(time.strftime("%X"))
vuln="\r\33[97m[\33[0m%s\33[97m] [\33[92mPOTENTIAL\33[97m]\33[0m "%(time.strftime("%X"))
warn="\33[92m[\33[93m!\33[92m] \33[91m"
prr="\33[92m[\33[95m+\33[92m] \33[91m"
